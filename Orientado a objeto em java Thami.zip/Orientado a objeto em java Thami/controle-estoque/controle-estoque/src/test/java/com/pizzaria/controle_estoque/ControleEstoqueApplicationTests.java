package com.pizzaria.controle_estoque;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControleEstoqueApplicationTests {

	@Test
	void contextLoads() {
	}

}
