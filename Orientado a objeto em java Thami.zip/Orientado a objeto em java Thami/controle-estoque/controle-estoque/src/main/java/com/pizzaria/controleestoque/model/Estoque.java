package com.pizzaria.controleestoque.model;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Estoque {
    private static final String ARQUIVO_ESTOQUE = "estoque.txt";
    private List<Produto> produtos = new ArrayList<>();

    // Carregar os produtos do arquivo
    public Estoque() {
        carregarEstoque();
    }

    // Adicionar produto
    public void adicionarProduto(Produto produto) {
        produtos.add(produto);
        salvarEstoque();
    }

    // Buscar produto por nome
    public Produto buscarProdutoPorNome(String nome) {
        for (Produto produto : produtos) {
            if (produto.getNome().equalsIgnoreCase(nome)) {
                return produto;
            }
        }
        return null; // Produto não encontrado
    }

    // Atualizar produto
    public void atualizarProduto(Produto produtoAtualizado) {
        Produto produtoExistente = buscarProdutoPorNome(produtoAtualizado.getNome());
        if (produtoExistente != null) {
            produtoExistente.setQuantidade(produtoAtualizado.getQuantidade());
            produtoExistente.setPreco(produtoAtualizado.getPreco());
            salvarEstoque();
        }
    }

    // Listar produtos
    public List<Produto> listarProdutos() {
        return produtos;
    }

    // Salvar produtos no arquivo
    private void salvarEstoque() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ARQUIVO_ESTOQUE))) {
            for (Produto produto : produtos) {
                writer.write(produto.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Carregar os produtos do arquivo
    private void carregarEstoque() {
        produtos.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(ARQUIVO_ESTOQUE))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                String[] dados = linha.split(",");
                produtos.add(new Produto(dados[0], Integer.parseInt(dados[1]), Double.parseDouble(dados[2])));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
