package com.pizzaria.controleestoque.model;

import java.util.Map;

public class Pizza {
    private String nome;
    private Map<String, Integer> ingredientes;  // Nome do ingrediente e quantidade usada

    public Pizza(String nome, Map<String, Integer> ingredientes) {
        this.nome = nome;
        this.ingredientes = ingredientes;
    }

    // Getters e Setters
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Map<String, Integer> getIngredientes() {
        return ingredientes;
    }

    public void setIngredientes(Map<String, Integer> ingredientes) {
        this.ingredientes = ingredientes;
    }

    @Override
    public String toString() {
        return nome + ": " + ingredientes.toString();
    }
}
