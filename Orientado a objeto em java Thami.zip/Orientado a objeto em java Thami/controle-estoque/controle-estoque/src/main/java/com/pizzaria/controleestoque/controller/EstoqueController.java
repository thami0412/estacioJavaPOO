package com.pizzaria.controleestoque.controller;

import com.pizzaria.controleestoque.model.Estoque;
import com.pizzaria.controleestoque.model.Pizza;
import com.pizzaria.controleestoque.model.Produto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/estoque")
public class EstoqueController {
	
	private Estoque estoque = new Estoque();
    private List<Pizza> pizzasMontadas = new ArrayList<>();  // Lista para armazenar as pizzas montadas

    @GetMapping("/")
    public String exibirMenuInicial() {
        return "index";  // Redireciona para o menu inicial
    }

    // Exibe a tela para montar pizza
    @GetMapping("/montarPizza")
    public String exibirTelaMontarPizza(Model model) {
        model.addAttribute("produtos", estoque.listarProdutos());
        return "montarPizza";
    }

    // Processa a montagem da pizza e abate do estoque
    @PostMapping("/finalizarPizza")
    public String finalizarPizza(@RequestParam String nomePizza, @RequestParam Map<String, String> ingredientes, Model model) {
        Map<String, Integer> ingredientesUsados = new HashMap<>();

        // Processar os ingredientes e quantidades
        for (String key : ingredientes.keySet()) {
            if (key.startsWith("ingredientes[")) {
                String nomeIngrediente = key.substring(13, key.length() - 1);  // Extrai o nome do ingrediente
                int quantidadeUsada = Integer.parseInt(ingredientes.get(key));

                Produto produto = estoque.buscarProdutoPorNome(nomeIngrediente);
                if (produto != null && quantidadeUsada > 0) {
                    produto.setQuantidade(produto.getQuantidade() - quantidadeUsada);
                    estoque.atualizarProduto(produto);  // Atualiza o estoque
                    ingredientesUsados.put(nomeIngrediente, quantidadeUsada);  // Adiciona o ingrediente e a quantidade usada
                }
            }
        }

        // Cria e salva a pizza montada
        Pizza pizza = new Pizza(nomePizza, ingredientesUsados);
        pizzasMontadas.add(pizza);

        return "redirect:/estoque/listar";  // Redireciona para listar o estoque atualizado
    }

    // Exibe a lista de pizzas montadas
    @GetMapping("/pizzasMontadas")
    public String listarPizzasMontadas(Model model) {
        model.addAttribute("pizzas", pizzasMontadas);
        return "pizzasMontadas";
    }
    

    // Método para exibir o formulário de cadastro de produto
    @GetMapping("/cadastro")
    public String exibirFormularioCadastro() {
        return "cadastro";
    }

    // Método para adicionar o produto ao estoque
    @PostMapping("/adicionar")
    public String adicionarProduto(@RequestParam String nome, @RequestParam int quantidade, @RequestParam double preco, Model model) {
        Produto produto = new Produto(nome, quantidade, preco);
        estoque.adicionarProduto(produto);
        model.addAttribute("mensagem", "Produto adicionado com sucesso!");
        return "cadastro";
    }

    // Método para listar todos os produtos no estoque
    @GetMapping("/listar")
    public String listarProdutos(Model model) {
        model.addAttribute("produtos", estoque.listarProdutos());
        return "estoque";
    }

    // Método para exibir o formulário de edição de produto
    @GetMapping("/editar/{nome}")
    public String exibirFormularioEdicao(@PathVariable String nome, Model model) {
        Produto produto = estoque.buscarProdutoPorNome(nome);
        model.addAttribute("produto", produto);
        return "editar";
    }

    // Método para salvar as alterações de um produto editado
    @PostMapping("/editar")
    public String editarProduto(@RequestParam String nome, @RequestParam int quantidade, @RequestParam double preco, Model model) {
        Produto produto = new Produto(nome, quantidade, preco);
        estoque.atualizarProduto(produto);
        return "redirect:/estoque/listar";
    }
    
    
    @GetMapping("/baixo")
    @ResponseBody
    public List<Produto> listarProdutosComEstoqueBaixo() {
        return estoque.listarProdutos().stream()
                //.filter(produto -> produto.getQuantidade() < 10)
                .collect(Collectors.toList());
    }
}
